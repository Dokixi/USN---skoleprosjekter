<?php 	/* index */
/*
/* 		Programmet lager hovedsiden
*/
include("start.html");
?>

<h3>Velkommen til startsiden </h3>
I menyen til venstre finner du ulike valg som kan utf&oslash;res ved bruk av denne applikasjonen

<?php
include("slutt.html");
?>